package dao;

import java.util.List;

import dto.EstudianteDTO;

public class EstudianteDAO {
    public void registrarEstudiante(EstudianteDTO estudiante) {
        
    }

    public List<EstudianteDTO> listarEstudiantesCompletaronCurso(String tituloCurso) {
		return null;
   
    }
}
