package Vista;

import java.awt.Menu;

public class Principal {
    public static void main(String[] args) {
        Menu menu = new Menu();
        
    }
}
